# Raspberry-Pi-Installer-Scripts

Some scripts for helping install Adafruit HATs, bonnets, add-on's, & friends!

Based heavily on get.pimoroni.com scripts!

  * Install i2s amplifier with: curl -sS https://raw.githubusercontent.com/adafruit/Raspberry-Pi-Installer-Scripts/master/i2samp.sh | bash